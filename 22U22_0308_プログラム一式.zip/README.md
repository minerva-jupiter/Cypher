Hi this is "Cypher"

This is a new cryptographic technology we propose.

This is based on the principle of combination.

We'll improve this program more.

We hope it will be one of the Post-Quantum Cryptography.

・tipe "createKey" to create keyFile for Cryptography.
	How to Answer "Where will you want to create the keyFile?"
	→You have to answer the file name with fullPath. (ex,C:\Users\minerva\Documant\date.txt)
		

・tipe "encrypt" to encrypt the date file you want with created keyFile.
	How to Answer "Where will you create encrypted file? (folder Name)"
	→You have to answer the folder path.(ex.If you want to create encrypted file "C:\Users\minerva\Document\encrypted.cypher",type "C:\Users\minerva\document")
		you can't select extension,encrypted file's path has .cypher extension.
		And you have to remember the file of extension. This is becouse when you sort use this.

・tipe "sort" to sort the encrypted file with keyFile.
	how to Answer "Where will you create sorted file?"
	→You have to answer the folder fullPath with encrypted file's extension.
		ex.If you encrypted C:\Users\minerva\Document\data.txt, you have to type "anywhere you want + filename you want + .txt"

・tipe "end" to end this program.

*****warning*****
You have to answer 'fullPath' apart from encrypted file's folderName.

Open file and try more! 

Thank you for reading:)
